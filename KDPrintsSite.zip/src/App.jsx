import React from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, ArrowRight, Award, Shield, Clock, Users } from "lucide-react";

const COMPANY = {
  name: "KD Prints Pvt. Ltd.",
  tagline: "Where Thread Meets Excellence",
  description:
    "A distinguished name in textile manufacturing with 35+ years of expertise, delivering premium and sustainable fabrics for global markets.",
  logoText: "KD",
  phone: "+91 9158656608",
  email: "sarthak@kdprints.in",
  website: "www.kdprints.in",
  address: "Meerut, India",
};

const HIGHLIGHTS = [
  { icon: <Award className="w-5 h-5" />, text: "35+ Years Expertise" },
  { icon: <Shield className="w-5 h-5" />, text: "Global Sustainability Standards" },
  { icon: <Clock className="w-5 h-5" />, text: "5 Lakh meters Monthly Capacity" },
  { icon: <Users className="w-5 h-5" />, text: "Trusted by Global Retailers" },
];

const PRODUCTS = [
  { title: "100% Linen Fabrics", desc: "Plain & Yarn Dyed up to 130\", breathable, strong, eco-friendly." },
  { title: "Linen Blends", desc: "Linen-Cotton, Linen-Viscose, Linen-Silk blends — strength & luxury at better cost." },
  { title: "Silk & Silk Blends", desc: "Luxurious texture, vibrant dyeability for fashion and interiors." },
  { title: "Hemp & Hemp Blends", desc: "Eco-friendly, durable, antibacterial fabrics with growing demand." },
  { title: "Jacquards", desc: "Up to 130\" width, complex patterns for upholstery & fashion." },
  { title: "Dobby Fabrics", desc: "Intricate textures, lightweight to heavy fabrics for shirts, dresses, décor." },
];

const CERTIFICATIONS = [
  "GOTS – Organic certified fabrics",
  "OEKO-TEX® – Safe for consumers",
  "OCS – Verified organic content",
  "BCI – Better Cotton Initiative",
  "Approved Supplier for Target & INDITEX",
];

const SectionTitle = ({ title, subtitle }) => (
  <div className="text-center max-w-2xl mx-auto mb-12">
    <h2 className="text-3xl md:text-4xl font-bold text-gray-900">{title}</h2>
    {subtitle && <p className="mt-3 text-gray-600">{subtitle}</p>}
  </div>
);

export default function KDPrintsSite() {
  return (
    <div className="font-sans text-gray-900">
      {/* HERO */}
      <section className="relative bg-gray-50 py-20">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">{COMPANY.tagline}</h1>
            <p className="mt-5 text-gray-600 md:text-lg">{COMPANY.description}</p>
            <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
              {HIGHLIGHTS.map((h, i) => (
                <div key={i} className="flex items-center gap-2 bg-white border rounded-2xl p-3 shadow-sm">
                  {h.icon}
                  <span className="text-sm text-gray-700">{h.text}</span>
                </div>
              ))}
            </div>
          </motion.div>
          <div className="aspect-[4/3] rounded-3xl bg-gradient-to-br from-gray-100 to-white border flex items-center justify-center text-gray-500">
            KD Prints — Fabrics Since 1988
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <SectionTitle title="About Us" subtitle="Vision: To be a global leader in sustainable textile manufacturing. Mission: Provide eco-friendly, innovative textile products." />
          <p className="text-gray-600 text-center max-w-3xl mx-auto">
            Our Meerut plant is equipped with advanced European machinery including Sulzer, Somet, Picanol looms, Jumbo Jacquards, and warping machines, enabling precision and scalability.
          </p>
        </div>
      </section>

      {/* PRODUCTS */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-6">
          <SectionTitle title="Product Range" subtitle="Diverse, sustainable fabrics for global markets" />
          <div className="grid md:grid-cols-3 gap-6">
            {PRODUCTS.map((p, i) => (
              <div key={i} className="bg-white rounded-3xl border p-6 shadow-sm">
                <h3 className="font-semibold text-lg">{p.title}</h3>
                <p className="text-gray-600 mt-2 text-sm">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CERTIFICATIONS */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-6">
          <SectionTitle title="Certifications & Compliance" />
          <ul className="space-y-2 text-gray-700">
            {CERTIFICATIONS.map((c, i) => (
              <li key={i}>✅ {c}</li>
            ))}
          </ul>
        </div>
      </section>

      {/* CONTACT */}
      <section className="py-20 bg-gray-900 text-gray-100">
        <div className="max-w-5xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-start">
          <div>
            <SectionTitle title="Contact Us" subtitle="Let’s Partner for a Sustainable Future" />
            <div className="space-y-4">
              <div className="flex items-center gap-3"><Phone /> {COMPANY.phone}</div>
              <div className="flex items-center gap-3"><Mail /> {COMPANY.email}</div>
              <div className="flex items-center gap-3"><MapPin /> {COMPANY.address}</div>
              <div className="mt-4">🌐 {COMPANY.website}</div>
            </div>
          </div>
          <form className="bg-white text-gray-800 rounded-3xl p-6 shadow-sm">
            <h3 className="font-semibold mb-4">Quick Message</h3>
            <input placeholder="Your Name" className="w-full border rounded-xl px-4 py-3 mb-3" />
            <input placeholder="Your Email" className="w-full border rounded-xl px-4 py-3 mb-3" />
            <textarea rows={4} placeholder="Message" className="w-full border rounded-xl px-4 py-3 mb-3" />
            <button type="submit" className="bg-gray-900 text-white px-5 py-3 rounded-xl flex items-center gap-2">Send <ArrowRight /></button>
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-black text-gray-400 py-6 text-center">
        © {new Date().getFullYear()} {COMPANY.name}. All rights reserved.
      </footer>
    </div>
  );
}
